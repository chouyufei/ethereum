python ./generate.py | tred | dot -Tpng > dependency_graph.png
python ./generate.py | tred | dot -Tsvg > dependency_graph.svg
