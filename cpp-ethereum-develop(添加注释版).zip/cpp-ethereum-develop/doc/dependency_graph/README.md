
To generate the `dependency_graph.svg` the executables `tred` and `dot` are required from the
[graphviz](http://www.graphviz.org/) package.

## Installing Graphviz on OSX

```
brew update
brew install graphviz
```
