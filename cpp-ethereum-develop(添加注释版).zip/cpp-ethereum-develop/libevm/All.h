#pragma once

#include "ExtVMFace.h"
#include "VM.h"
